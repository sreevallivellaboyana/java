
import java.util.ArrayList;
import java.util.Collections;

class vehicle implements Comparable<vehicle>
{
	long price;
	String carName;
	String brand;
	
	vehicle(int price,String carName,String brand)
	{
		
		this.price= price;
		this.carName=carName;
		this.brand=brand;
	}
	public String toString() 
	  	{ 
		  return "{"+carName+"|"+brand+"|"+price+"}" ;
	  	}
	  
	  @Override
	public int compareTo(vehicle c) {
		  
		return this.carName.compareTo(c.carName);
		
	}
}
public class assign1 {

	public static void main(String[] args) {
	

		
		ArrayList<vehicle> car=new ArrayList<vehicle>();
		
		car.add(new vehicle(800000,"Nexa","M.Suzuki"));
		car.add(new vehicle(580000,"Punch","Tata"));
		car.add(new vehicle(7200000,"Z4","BMW"));
		car.add(new vehicle(75000000,"Wraith","Rolls-Royce"));
		car.add(new vehicle(40100000,"F8 Tributo","Ferrari"));
		Collections.sort(car);
		System.out.println(car);
		
	}}