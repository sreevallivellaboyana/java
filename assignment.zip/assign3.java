import java.util.ArrayList;

class HPCharacter 
{
	String name;
	String house;
	String role;
	String status;
	String dies;
	
	HPCharacter(String name,String house,String role,String status,String dies)
	{
		
		this.name= name;
		this.house=house;
		this.role=role;
		this.status=status;
		this.dies=dies;
		
	}
	public String getName()
	{
		return name;
	}
public String getHouse()
	{
	return house;
	}
public String getRole()
	{
	return role;
	}
public String getStatus()
	{
	return status;
	}
public String getDies()
	{
	return dies;
	}
	
	  public String toString() 
	  	{ 
		  return "{"+name+ "|"+house+"|"+role+"|"+status+"|"+dies+"}";
	  	}
	  public ArrayList getGryffindor(ArrayList<HPCharacter> c)
	  {
		  
		  ArrayList<String> gryffindor=new ArrayList<>();
			for (HPCharacter person: c) {

	            if (person.getHouse()=="Gryffindor") {

	            	gryffindor.add(person.getName());
	            }
	        }
		  
		  return gryffindor;
	  }
	  public ArrayList getAlive(ArrayList<HPCharacter> c)
	  {
		  ArrayList<HPCharacter> alive=new ArrayList<>();
			for (HPCharacter person: c) {

	            if (person.getDies()=="No") 
	            	alive.add(person);
			}
		
			alive.sort((o1, o2) -> o1.getHouse().compareTo(o2.getHouse()));
			return alive;
	  }
	
			
public ArrayList getFamily(ArrayList<HPCharacter> a)
{
	
	  ArrayList<HPCharacter> family=new ArrayList<>();
		for (HPCharacter person: a) {

          if (person.getStatus()=="Family") {

          	family.add(person);
          }
      }
	  
	  return family;
}

public ArrayList getFaculty(ArrayList<HPCharacter> a)
{
	
	  ArrayList<HPCharacter> faculty=new ArrayList<>();
		for (HPCharacter person: a) {

          if (person.getDies()=="Yes"&& person.getRole()=="Faculty") {

          	faculty.add(person);
          }
      }
		faculty.sort((b, c) -> b.getName().compareTo(c.getName()));
		return faculty;
}


}

public class assign3 {

	public static void main(String[] args) {
	

		
		ArrayList<HPCharacter> a=new ArrayList<HPCharacter>();
    ArrayList<String> result1 = new ArrayList<String>();
		ArrayList<HPCharacter> result2=new ArrayList<HPCharacter>();
		ArrayList<HPCharacter> result3=new ArrayList<HPCharacter>();
		ArrayList<String> result4 = new ArrayList<String>();
		
		a.add(new HPCharacter("Harry Potter","Gryffindor","Student","Self","No"));
		a.add(new HPCharacter("Ginny Weasley","Gryffindor","Student","Friend","No"));
		a.add(new HPCharacter("Ron Weasley","Gryffindor","Student","Friend","No"));
		a.add(new HPCharacter("Hermione Granger","Gryffindor","Student","Friend","No"));
		a.add(new HPCharacter("Neville Longbottom","Gryffindor","Student","Friend","No"));
		a.add(new HPCharacter("Albus Dumbledore","Gryffindor","Faculty","Friend","Yes"));
		a.add(new HPCharacter("Remus Lupin","Gryffindor","Faculty","Friend","Yes"));
		a.add(new HPCharacter("Peter Pettigrew","Gryffindor","Student","Enemy","Yes"));
		a.add(new HPCharacter("Oliver Wood","Gryffindor","Student","Friend","No"));
		a.add(new HPCharacter("Lily Potter","Gryffindor","Student","Family","Yes"));
		a.add(new HPCharacter("Sirius Black","Gryffindor","Student","Friend","Yes"));
		a.add(new HPCharacter("James Potter","Gryffindor","Student","Family","Yes"));
		a.add(new HPCharacter("Minerva McGonagall","Gryffindor","Faculty","Friend","No"));
		a.add(new HPCharacter("Rubeus Hagrid","Gryffindor","Faculty","Friend","No"));
		a.add(new HPCharacter("Draco Malfoy","Slytherin","Student","Enemy","No"));
		a.add(new HPCharacter("Vincent Crabbe","Slytherin","Student","Enemy","Yes"));
		a.add(new HPCharacter("Gregory Goyle","Slytherin","Student","Enemy","No"));
		a.add(new HPCharacter("Penelope Clearwater","Slytherin","Student","Enemy","No"));
		a.add(new HPCharacter("Severus Snape","Slytherin","Faculty","Enemy","Yes"));
		a.add(new HPCharacter("Horace Slughorn","Slytherin","Student","Friend","No"));
		a.add(new HPCharacter("Tom Marvolo Riddle","Slytherin","Student","Enemy","Yes"));
		a.add(new HPCharacter("Luna Lovegood","Ravenclaw","Student","Friend","No"));
		a.add(new HPCharacter("Cho Chang","Ravenclaw","Student","Friend","No"));
		a.add(new HPCharacter("Hannah Abbot","Hufflepuff","Student","Friend","No"));
		a.add(new HPCharacter("Cedric Diggory","Hufflepuff","Student","Friend","Yes"));
		
		HPCharacter obj=new HPCharacter(null, null, null, null, null);
		result1=obj.getGryffindor(a);
		result2=obj.getAlive(a);
		result3=obj.getFamily(a);
		result4=obj.getFaculty(a);
	}
}
