import java.util.Scanner;

class account {
 
    private int balance = 1000;
 
    public int balance() {
        return balance;
    }
 
    public void withdraw(int amount) throws insufficientFundException {
        if (amount > balance) {
            throw new insufficientFundException(
   String.format("Requested amount %d is more than Current balance %d ", amount, balance));
        }
        balance = balance - amount;
    }
 
}
class insufficientFundException extends RuntimeException {
 
    private String message;
 
    public insufficientFundException(String message) {
        this.message = message;
    }
 
    public insufficientFundException(Throwable inf, String message) {
        super(inf);
        this.message = message;
    }
 
    public String getMessage() {
        return message;
    }

}

public class assign2 {

  private static final String REQUESTED_AMOUNT_SHOULD_BE_POSITIVE = "Requested amount should be positive";
 
  private static final String ENTER_THE_ANOUNT_TO_WITHDRAW = "Enter the anount to withdraw: ";

  public static void main(String[] args) {
		account acc = new account();
        System.out.println("Current balance : " + acc.balance());
        try (Scanner check = new Scanner(System.in)) {
          System.out.println(ENTER_THE_ANOUNT_TO_WITHDRAW);
          int wth=check.nextInt();
          if(wth>0)
          {
          System.out.println(String.format("Withdraw78 %d",wth));
          acc.withdraw(wth);
          }
          else
          System.out.println(REQUESTED_AMOUNT_SHOULD_BE_POSITIVE);
        } catch (insufficientFundException e) {
          
          e.printStackTrace();
        }
        System.out.println("Current balance : " + acc.balance());
	}

}